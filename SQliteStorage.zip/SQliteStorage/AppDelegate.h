//
//  AppDelegate.h
//  SQliteStorage
//
//  Created by Naresh Kongara on 9/22/17.
//  Copyright © 2017 Naresh Kongara. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

